# File Upload and Download
 To create a simple website using Django where admin of the website can easily upload the file and the user of that website download that uploaded flle
