from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from .forms import UserRegisterForm,UserUpdateForms,ProfileUpdateForm
from django.contrib import messages
from django.views.generic import ListView,DetailView,CreateView
from .models import Profile
from django.contrib.auth import login,authenticate
# Create your views here.


def home(request,*args, **kwargs):
    # print("start")
    # code = str(kwargs.get('ref_code'))
    # print("code")
    # print("code",code)
    # try:
    #     print("tryyy")
    #     profile = Profile.objects.get(code=code)
    #     request.session['ref_profile'] = profile.id
    #     print("pro",profile.id)
    #     # return(pro)
    # except:
    #     pass
        # return(EOFError)

    return render(request, 'home.html')



def refral_veiws(request,*args, **kwargs):
    # print("start")
    # code = str(kwargs.get('ref_code'))
    # print("code")
    # print("code",code)
    # try:
    #     print("tryyy")
    #     profile = Profile.objects.get(code=code)
    #     print("profile")
    #     profile("profile",profile)
    #     request.session['ref_profile'] = profile.id
    #     print("profileid")
    #     print("pro",profile.id) print("start")
    code = str(kwargs.get('ref_code'))
    print("code")
    print("code",code)
    try:
        print("tryyy")
        profile = Profile.objects.get(code=code)
        print("profile")
        profile("profile",profile)
        request.session['ref_profile'] = profile.id
        print("profileid")
        print("pro",profile.id)
        # return(pro)
    except:
        pass
    #     # return(pro)
    # except:
    #     pass
        # return(EOFError)

    # query = request.GET['search']
    # code = query
    # print("query",query)
    # print('code',code)
    # # code = str(kwargs.get('ref_code'))
    # print("code")
    # print("code",code)
    # try:
    #     print("tryyy")
    #     profile = Profile.objects.get(code=code)
    #     request.session['ref_profile'] = profile.id
    #     print("pro",profile.id)
    #     # return(pro)
    # except:
    #     pass


    return render(request,'refral_id.html',{})


def register(request,*args, **kwargs):
    profile_id = request.session.get('ref_profile')
    print("getttttttt")
    print('profile_id', profile_id)
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        if profile_id is not None:
            recomended_by_profile = profile.objects.get(id=profile_id)

            instance = form.save()
            register_user = User.objects.get(id=instance.id)
            register_profile = profile.objects.get(user =register_profile)
            register_profile_recommended_by = recomended_by_profile.user
            register_profile.save
        else:
            form.save()
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password1')
        user = authenticate(username = username, password=password)
        login(request,user)
        
        messages.success(request,f'Your Account Has Been Created for {username} Please LogIn')
        return redirect('login')
    context = {'form':form, 'message':messages}
    return render(request, 'register.html',context)

def registe(request,*args, **kwargs):
    profile_id = request.session.get('ref_profile')
    # if request.method =='POST':

    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        if profile_id is not None:
            recomended_by_profile = Profile.objects.get(id =profile_id)
            instance = form.save()
            print("1stsavw")
            register_profile = Profile.objects.get(user = recomended_by_profile)
            register_profile.recomended_by = recomended_by_profile.user
            register_profile.save()
            print("save")
                
                # username = form.cleaned_data.get('username')
                # messages.success(request,f'Your Account Has Been Created for {username} Please LogIn')
                # return redirect('login')
        else:
            form.save()
            #     return render(request,'home.html')       register_user = User.objects.get(id = profile_id)

            # form.save() 
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password1')
        user = authenticate(username=username,password=password)
        print("auth")
        login(request,user)

        messages.success(request,f'Your Account Has Been Created for {username} Please LogIn')
        return redirect('login')
        # else:
        #     form = UserRegisterForm()
    form = UserRegisterForm
    return render(request,'register.html',context={'form':form})

@login_required
def profile(request):
        profile = Profile.objects.get(user=request.user)
        my_recs = profile.get_recomended_code()
        bio = profile.bio

        context = {
            'bio' : bio,
            'my_recs' : my_recs,

        }
        return render(request, 'profile.html',context)


class ArticleDetail(DetailView):
    # model = profile.objects.all()
    template_name = 'articledetail.html'

def search(request,*args, **kwargs):
    print("start")
    code = str(kwargs.get('ref_code'))
    print("code")
    print("code",code)
    try:
        print("tryyy")
        profile = Profile.objects.get(code=code)
        print("profile")
        profile("profile",profile)
        request.session['ref_profile'] = profile.id
        print("profileid")
        print("pro",profile.id)
        # return(pro)
    except:
        pass
    print("search fuv=nt start")
    if request.method =='GET':
        print("tttt")
        query = request.GET.get('search')
        print("query",query)
        post = Profile.objects.all().filter(code=query)
        print("query------------",query)
        return render(request,'referal.html',{'post':post})
    else:
        return render(request,'home.html')




    # query = request.GET['query']
    # print(query)
    # allposts= Profile.objects.filter(request.code==query)
    # allpost = Profile.objects.filter(Cotegory__icontains=query)
    # params = {'allpost': allpost}
    # return render(request,'register.html', params)

# def my_reccom_view(request):
#     profile = Profile.objects.get(user=request.user)
#     my_recs = profile.get_recomended_code()
#     context = {'my_recs': my_recs}
#     return render(request, 'main.html'context)