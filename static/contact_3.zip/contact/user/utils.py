import uuid

def recomeded_code():
    code = str(uuid.uuid4()).replace("-","")[:8]
    return code